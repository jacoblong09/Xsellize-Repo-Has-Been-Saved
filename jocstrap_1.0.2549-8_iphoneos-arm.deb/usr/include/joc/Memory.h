#ifndef JOC_MEMORY_H
#define JOC_MEMORY_H

#include <apr_pools.h>

extern apr_pool_t *apr_pool_;

void mem_Initialize();

#endif/*JOC_MEMORY_H*/
