#ifndef __FE_RECODE_H
#define __FE_RECODE_H

void fe_recode_init (void);
void fe_recode_deinit (void);

#endif /* __FE_RECODE_H */
