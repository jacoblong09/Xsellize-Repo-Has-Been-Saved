# Cydia - iPhone UIKit Front-End for Debian APT
# Copyright (C) 2008  Jay Freeman (saurik)
#
#
#
#        Redistribution and use in source and binary
# forms, with or without modification, are permitted
# provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the
#    above copyright notice, this list of conditions
#    and the following disclaimer.
# 2. Redistributions in binary form must reproduce the
#    above copyright notice, this list of conditions
#    and the following disclaimer in the documentation
#    and/or other materials provided with the
#    distribution.
# 3. The name of the author may not be used to endorse
#    or promote products derived from this software
#    without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS''
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
# ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#!/bin/bash


touch /var/lib/dpkg/available /var/lib/dpkg/status
if ! grep '^Package: com.rockyourphone.rockapp$' /var/lib/dpkg/status >/dev/null; then
    cat /var/lib/dpkg/status - >/var/lib/dpkg/status__ <<EOF
Package: com.rockyourphone.rockapp
Essential: no
Status: install ok installed
Priority: required
Section: System
Maintainer: bugs@rockyourphone.com
Architecture: iphoneos-arm
Version: 2.57.2
Description: Fully featured community APT installer with leading App Store.   
 
 Features:
 
 - Install and Manage Applications - Including APT/Cydia Sources
 - Free Trials of new software from Rock Your Phone 
 - Backup/Restore of Jailbroken Apps
 - Queue Installs - browse/search while installing/downloading
 - Search Names and Descriptions - Better search results then Cydia/Icy
 - Purchase License for Applications
 - Easily email developers your syslog for assistance troubleshooting
 - See all new apps - not just updated (also filter to show only apps)
 - Sort by Name, Rating, or Release Date
Name: RockApp
Maintainer: Rock Your Phone
Homepage: http://www.rockyourphone.com
Support: http://support.rockyourphone.com

EOF
mv -f /var/lib/dpkg/status{__,}
fi 

if ! grep '^Package: base$' /var/lib/dpkg/status >/dev/null; then
    cat /var/lib/dpkg/status - >/var/lib/dpkg/status__ <<EOF
Package: base
Essential: yes
Status: install ok installed
Priority: required
Section: System
Installed-Size: 260
Maintainer: Apple
Architecture: iphoneos-arm
Version: 1-3
Description: underlying system directory structure
Name: Base Structure

EOF
mv -f /var/lib/dpkg/status{__,}

fi 

