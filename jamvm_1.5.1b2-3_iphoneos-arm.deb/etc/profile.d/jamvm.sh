export BOOTCLASSPATH=/usr/share/jamvm/classes.zip:/usr/lib/rt.jar
