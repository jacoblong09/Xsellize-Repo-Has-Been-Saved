#35 Cal Crutchlow LS by @iMaC7419
  
This Lockscreen has it's own Clock Widget :-

Install LockScreen Clock Hide from Cydia,

iFile or any SSH program to edit the Weather Location :-

open the LockScreen.html file with Text Viewer "iFile" or 
WordPad/NotePad on your desktop scroll down until you see 

var locale = "UKXX1551"

Replace UKXX1551 with your own Weather location code.

☠ Thanks for your support ☠